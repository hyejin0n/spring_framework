package com.springboot.webapp.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

@Repository("boardDao")
public class BoardDao {

	// Mysql
	static String id = "root";
	static String pass = "111111";
	static String url = "jdbc:mysql://localhost:3306/springdb?characterEncoding=utf-8";

	Connection conn = null;
	PreparedStatement postmt = null;
	ResultSet rs = null;

	public Connection getconn() {
		try {
			// 드라이버 로딩
			Class.forName("com.mysql.jdbc.Driver");
			// url, id, password 이용하여 디비 서버에 연결
			//System.out.println("드라이버 로딩 완료!");
			return DriverManager.getConnection(url, id, pass);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("드라이버 로딩 및 연결완료!");
		return null;
	}

	public void closeConn() {

		if(conn != null) {
			try {
				if (!conn.isClosed())
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				conn = null;
			}
		}

		if (rs != null) {
			try {
				if (!rs.isClosed())
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				rs = null;
			}
		}

		if (postmt != null) {
			try {
				if (!postmt.isClosed())
					postmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				postmt = null;
			}
		}
	}

	// insertBoard(Board dbo)
	// boardDo에 저장한 데이터를 디비에 저장하는 메소드
	public void insertBoard(BoardDo bdo) {
		System.out.println("InsertBoard() 시작!!");

		// 디비연결
		conn = getconn();
		// sql 완성
		String sql = "Insert into board values(null, ?,?,?)";
		try {
			postmt = conn.prepareStatement(sql);
			// 테이블의 정렬 순서와 일치해야함
			postmt.setString(1, bdo.getTitle());
			postmt.setString(2, bdo.getWriter());
			postmt.setString(3, bdo.getContent());

			// 3.sql실행
			// insert 문의 경우 테이블의 변화가 있기 때문에
			// executeUpdate() 메소드 이용
			postmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("insertBoard() 처리완료..!");
	}

	// GetBoardList()
	// board테이블에 있는 전체 데이터를 읽어와서 arrayList로 연결하는 메소드
	public ArrayList<BoardDo> getBoardList() {
		System.out.println("GetBoardList() start!");

		ArrayList<BoardDo> bList = new ArrayList<BoardDo>();
		// 1.디비 연결
		conn = getconn();

		// 2.sql문 완성
		String sql = "select * from board";
		try {
			// ?이 없어서.. 설정하는 코드 없음
			postmt = conn.prepareStatement(sql);

			// 3.sql실행
			// 실행 후에 여러개의 데이터가 전달될 수 있기 때문에 rs로 받아서 처리
			rs = postmt.executeQuery();
			while (rs.next()) {
				BoardDo bdo = new BoardDo();
				bdo.setSeq(rs.getInt(1));
				bdo.setTitle(rs.getString(2));
				bdo.setWriter(rs.getString(3));
				bdo.setContent(rs.getString(4));

				bList.add(bdo);

			}
			closeConn();
			System.out.println("getBoardList()처리 완료!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bList;
	}

	// getOnBoard()
	// board 테이블에서 하나의 데이터로 읽어와서 연결하는 메소드
	public BoardDo getOnBoard(BoardDo bdo) {
		System.out.println("getOnBoard() 처리 시작");
		// 리턴변수 선언
		BoardDo board = new BoardDo();

		// 1. 디비 연결
		conn = getconn();

		// 2. sql문 생성
		String sql = "select * from board where seq=?";
		try {
			postmt = conn.prepareStatement(sql);
			postmt.setInt(1, bdo.getSeq());

			// 3. sql.문 실행
			rs = postmt.executeQuery();
			while (rs.next()) {
				board.setSeq(rs.getInt(1));
				board.setTitle(rs.getString(2));
				board.setWriter(rs.getString(3));
				board.setContent(rs.getString(4));
			}
			// 4. 연결 해제
			closeConn();
			System.out.println("getOnBoard() 처리 완료");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return board;
	}

	// updateBoard(BoardDo.dbo)
	// bdo로 입력받는 데이터를 이용해서, board테이블을 수정(update)하는 메소드
	public void updateBoard(BoardDo bdo) {
		System.out.println("updateBoard() 처리 시작");
		// 1.디비연결
		conn = getconn();
		// 2.sql문 완성
		String sql = "update board set title=?, content=? where seq=?";
		try {
			postmt = conn.prepareStatement(sql);
			postmt.setString(1, bdo.getTitle());
			postmt.setString(2, bdo.getContent());
			postmt.setInt(3, bdo.getSeq());

			// 3.sql문 실행
			postmt.executeUpdate();
			// 4.연결 해제
			closeConn();
			System.out.println("updateBoard()처리 완료!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// deleteBoard(BoardDo.dbo)
	// bdo로 입력되는 seq에 해당하는 데이터를 board테이블에서 삭제하는 메소드
	public void deleteBoard(BoardDo bdo) {
		System.out.println("deleteBoard() 처리 시작!");
		// 1. db연결
		conn = getconn();
		// 2. sql문 완성
		String sql = "delete from board where seq=?";
		try {
			postmt = conn.prepareStatement(sql);
			postmt.setInt(1, bdo.getSeq());

			// 3. sql문 실행
			postmt.executeUpdate();
			// 4. 디비 연결 해제
			closeConn();
			System.out.println("deleteBoard() 처리 완료!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
