package com.springboot.webapp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.webapp.model.BoardDao;
import com.springboot.webapp.model.BoardDo;

@Service("boardService")
public class BoardServicecelmpl implements BoardService {
	//실제 메소드에 대한 구현
	@Autowired
	private BoardDao bdao;
	
	@Override
	public void InsertBoard(BoardDo bdo) {
		bdao.insertBoard(bdo);
		//지저분한건 BDAO에서 여기서는 호출만
	}

	@Override
	public ArrayList<BoardDo> getBoardList() {
		// TODO Auto-generated method stub
		return bdao.getBoardList();
	}

	@Override
	public BoardDo getOnBoardDo(BoardDo bdo) {
		// TODO Auto-generated method stub
		return bdao.getOnBoard(bdo);
	}

	@Override
	public void updateBoard(BoardDo bdo) {
		bdao.updateBoard(bdo);
	}

	@Override
	public void deleteBoard(BoardDo bdo) {
		// TODO Auto-generated method stub
		bdao.deleteBoard(bdo);
	}
}
