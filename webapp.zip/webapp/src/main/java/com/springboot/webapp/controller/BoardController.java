package com.springboot.webapp.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.webapp.model.BoardDao;
import com.springboot.webapp.model.BoardDo;

//@Controller : 사용자 요청을 처리하기 위한클래스를 만드는 어노테이션
@Controller
public class BoardController {

	// 1. insertBoard.do 요청이 오면, insertBoard.jsp 호출하는 메소드 
	@RequestMapping(value="/insertBoard.do")
	public String insertBoard() {
		return "insertboard";
	}
	
	// 2. inserProcBoard() : insertprocBoard.do 요청이 오면, BoardDo에 저장하고 
	// 해당 데이터를 디비에 저장하는 메소드
	@RequestMapping(value="/insertProcBoard.do")
	public String insertProcBoard(BoardDo bdo) {
		System.out.println("insertProcBoard 실행");
		//insertBoard.jsp로 부터 입력받은 데이터가
		//제대로 BoardDo 객체에 저장하여 있는지 확인 --> 디비 저장
		System.out.println("title: " + bdo.getTitle());
		System.out.println("title: " + bdo.getWriter());
		System.out.println("title: " + bdo.getContent());
		
		//Dao 이용하여 서버에 입력된 값을 저장
		BoardDao bdao = new BoardDao();
		bdao.insertBoard(bdo);
		System.out.println("Dao 이용 데이터 디비저장완료");
		
		//뷰어 이용하여 /boardviews/getBoardList.jsp. 호출
		//return "getBoardList";
		
		//전체 데이터를 가져오려면 컨트롤러의 getBoardList.do 매칭 메소드를 호출하여
		//전체 데이터를 가져와서 출력해주는 작업이 필요함
		//그래서, 아래의 내용은 뷰어를 호출하는것이 아닌, 컨트롤러의 처리 메소드를 호출하는 것임
		//이떄, 필요한 키워드는 redirect 임.
		return "redirect:getBoardList.do";
		
	}
	
	@RequestMapping(value="getBoardList.do")
	//public String getBoardList(BoardDo bod, BoardDao bdao, ModelAndView mav ) {
	public ModelAndView getBoardList(BoardDo bod, BoardDao bdao, ModelAndView mav) {
		System.out.println("getBoardList() 처리");
		//전체 데이터를 디비에서 긁어오는 처리 후에 뷰어 호출
		ArrayList<BoardDo> bList = bdao.getBoardList();
		for(BoardDo bdo : bList) {
			System.out.println("-->" + bdo.toString());
		}
		
		//ModelAndView를 이용하여 뷰어를 호출하면서 데이터를 전달함.
		//addObject("뷰어에 전달하는 변수 명","데이터를 읽어오는 변수명)"
		mav.addObject("bList", bList);
		//setViewName("뷰어이름") 이용하여 뷰어 호출
		mav.setViewName("getBoardList");
		
		return mav;
	}
	
	
}
